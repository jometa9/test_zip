"""
MetaTrader 4 login automation script
Implements server discovery using UI automation (no OCR/screenshots)
"""

import sys
import time
import os
from pathlib import Path

# Fix encoding for Windows console (cp1252) - use environment variable instead
# This is safer when running from Node.js as it doesn't replace sys.stdout/stderr
if sys.platform == 'win32':
    os.environ['PYTHONIOENCODING'] = 'utf-8'

# Add parent directory to path to import base
sys.path.insert(0, str(Path(__file__).parent))
from base import MetaTraderLoginBase

try:
    import pyautogui
except ImportError:
    print("ERROR: pyautogui not installed. Install with: pip install pyautogui")
    sys.exit(1)


class MT4Login(MetaTraderLoginBase):
    """MetaTrader 4 specific login automation with server discovery"""
    
    def __init__(self, mt_path: str, login: str, password: str, server: str, timeout: int = 60):
        """Initialize MT4 login automation"""
        super().__init__(mt_path, login, password, server, timeout)
        self.current_row = 0
        self.max_rows = 0
    
    def navigate_to_server_window(self) -> bool:
        """
        Navigate to the server selection window
        
        Returns:
            True if window found and activated, False otherwise
        """
        print("\n[Step 1] Waiting for 'Open an Account' window...")
        sys.stdout.flush()
        
        open_account_window = self.find_window_by_title(
            "Open an Account|Open Account|Abrir una cuenta", 
            timeout=30
        )
        
        if not open_account_window:
            print("[ERROR] 'Open an Account' window not found")
            sys.stdout.flush()
            return False
        
        print("\n[Step 2] Activating 'Open an Account' window...")
        sys.stdout.flush()
        self.activate_window(open_account_window)
        
        return True
    
    def inject_server_and_trigger_search(self) -> bool:
        """
        Inject server name in input and trigger search
        
        Returns:
            True if successful, False otherwise
        """
        print("\n[Step 3] Pressing Enter to focus input...")
        sys.stdout.flush()
        self.press_key('enter')
        
        print(f"\n[Step 4] Writing server name: {self.server}")
        sys.stdout.flush()
        self.type_text(self.server)
        
        print("\n[Step 5] Pressing Enter to trigger server search...")
        sys.stdout.flush()
        # Press Enter to search - this should trigger the search, not select a row
        # If the focus is in the list, this might select a row, so we need to be careful
        self.press_key('enter')
        
        # After pressing Enter, the focus might be in the list
        # We'll handle moving to the top after the list loads
        
        return True
    
    def wait_for_server_list_to_load(self, window: any, timeout: int = 60) -> bool:
        """
        Wait for server list to load by detecting when there are more than 1 items.
        If only 1 item appears, it's the loading row, so we keep checking
        every second until we get more than 1 item or timeout (60 seconds).
        If after 60 seconds we still have only 1 item, no servers were found.
        
        Args:
            window: Window object from pywinauto
            timeout: Maximum time to wait (default 60 seconds for non-existent brokers)
            
        Returns:
            True if list loaded with more than 2 items, False if timeout with only 1 item (cancel)
        """
        print("\n[Step 3] Waiting for server list to load...")
        print("[INFO] Will wait until more than 2 items appear (single item is loading row, not a server)")
        sys.stdout.flush()
        
        import time
        start_time = time.time()
        check_interval = 1.0  # Check every 1 second
        
        while time.time() - start_time < timeout:
            try:
                # Check item count
                item_count = self.get_list_items_count(window)
                
                # If we have more than 2 items, list has definitely loaded
                if item_count > 2:
                    print(f"[OK] Server list loaded: {item_count} items found (more than 2)")
                    sys.stdout.flush()
                    return True
                
                # If we have exactly 1 item, it might be the loading row
                # Keep checking until we get more items or timeout
                elapsed = int(time.time() - start_time)
                if elapsed > 0 and elapsed % 2 == 0:  # Log every 2 seconds
                    print(f"[INFO] Still waiting... ({elapsed}s elapsed, {item_count} item(s) - might be loading row)")
                    sys.stdout.flush()
                
            except Exception as e:
                print(f"[DEBUG] Error checking list status: {e}")
                sys.stdout.flush()
        
        # Timeout reached - check final count
        final_count = self.get_list_items_count(window)
        
        if final_count > 2:
            print(f"[OK] Server list loaded after timeout: {final_count} items found (more than 2)")
            sys.stdout.flush()
            return True
        elif final_count == 1:
            # After 60 seconds, if we still have only 1 item, cancel everything
            print(f"[ERROR] Timeout (60s) reached with only 1 item (loading row).")
            print(f"[ERROR] No servers found for '{self.server}'. Cancelling login process.")
            sys.stdout.flush()
            return False
        else:
            print(f"[ERROR] Timeout (60s) reached with 0 items. Server list did not load.")
            sys.stdout.flush()
            return False
    
    def count_server_rows(self, window: any) -> int:
        """
        Count how many server rows are available in the list
        Note: The last row is not a valid option, so we subtract 1
        Note: This function is only called after wait_for_server_list_to_load returns True,
        which means we have more than 1 item (single item = loading row, not a server)
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            Number of valid server rows (total - 1)
        """
        print("\n[Step 7] Counting server rows...")
        sys.stdout.flush()
        
        # Get count of list items
        # NOTE: This should not move the focus, but some pywinauto methods might
        total_count = self.get_list_items_count(window)
        
        # If we somehow have only 1 item here, it means wait_for_server_list_to_load
        # should have failed, but we'll handle it gracefully
        if total_count <= 1:
            print(f"[WARNING] Only {total_count} item(s) found. This should not happen after wait_for_server_list_to_load.")
            print(f"[WARNING] Returning 0 valid rows (single item is loading row, not a server)")
            sys.stdout.flush()
            return 0
        
        # Normal case: Subtract 1 because the last row is not a valid option
        valid_count = max(0, total_count - 1)
        
        if total_count > 0:
            print(f"[OK] Found {total_count} total rows, {valid_count} valid server rows (excluding last row)")
            sys.stdout.flush()
        else:
            print(f"[INFO] No list items found, will try to navigate manually")
            sys.stdout.flush()
        
        # IMPORTANT: After counting, ensure we're still at the top
        # Some pywinauto methods might have moved the selection
        print("[INFO] Ensuring we're still at top of list after counting...")
        sys.stdout.flush()
        try:
            self.activate_window(window)
            pyautogui.press('home')
            print("[OK] Confirmed at top of list (row 0)")
            sys.stdout.flush()
        except Exception as e:
            print(f"[WARNING] Could not ensure top position: {e}")
            sys.stdout.flush()
        
        return valid_count
    
    def navigate_to_row(self, row_number: int) -> bool:
        """
        Navigate to a specific row in the server list
        
        Args:
            row_number: Row number to navigate to (0-based)
            
        Returns:
            True if navigation successful, False otherwise
        """
        if row_number == 0:
            # Go to top of list
            print(f"[INFO] Navigating to top of list (row 0)...")
            sys.stdout.flush()
            pyautogui.press('home')
            return True
        
        # Navigate from current position
        if row_number > self.current_row:
            # Move down
            steps = row_number - self.current_row
            print(f"[INFO] Navigating down {steps} rows to row {row_number}...")
            sys.stdout.flush()
            for i in range(steps):
                pyautogui.press('down')
        elif row_number < self.current_row:
            # Move up
            steps = self.current_row - row_number
            print(f"[INFO] Navigating up {steps} rows to row {row_number}...")
            sys.stdout.flush()
            for i in range(steps):
                pyautogui.press('up')
        
        self.current_row = row_number
        return True
    
    def try_login_with_current_row(self, window: any) -> bool:
        """
        Try to login using the currently selected row
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            True if login successful, False otherwise
        """
        print(f"\n[Step 8] Trying login with row {self.current_row}...")
        sys.stdout.flush()
        
        # Ensure we're on the correct row before selecting
        # If we're trying row 0, make sure we're at the top
        if self.current_row == 0:
            print(f"  Ensuring we're at the top of the list (row 0)...")
            sys.stdout.flush()
            # Activate window to ensure focus
            self.activate_window(window)
            # Press Home to go to top
            pyautogui.press('home')
            print(f"  [OK] At top of list")
            sys.stdout.flush()
        else:
            # For other rows, navigate to them
            self.navigate_to_row(self.current_row)
        
        # Press Enter to select the server row
        print(f"  Pressing Enter to select server row {self.current_row}...")
        sys.stdout.flush()
        self.press_key('enter')
        
        # Wait for login form window to appear
        print(f"  Waiting for login form window...")
        sys.stdout.flush()
        login_window = self.find_window_by_title("Login|Account|Login to trade", timeout=10)
        
        if not login_window:
            print(f"  [ERROR] Login form window not found")
            sys.stdout.flush()
            return False
        
        print(f"  [OK] Login form window found, activating...")
        sys.stdout.flush()
        self.activate_window(login_window)
        
        # Fill login form
        print(f"  Filling login form...")
        sys.stdout.flush()
        if not self.fill_login_form(login_window, self.login_number, self.password):
            print(f"  [ERROR] Failed to fill login form")
            sys.stdout.flush()
            return False
        
        # Press Enter to submit
        print(f"  Pressing Enter to submit login...")
        sys.stdout.flush()
        self.press_key('enter')
        
        # TODO: Validate login success - for now, assume success if we got here
        # The validation will be done later when we're in the MetaTrader main window
        print(f"  [INFO] Login form submitted for row {self.current_row}")
        print(f"  [INFO] Validation will be done later in MetaTrader main window")
        sys.stdout.flush()
        return True
    
    def detect_end_of_list(self, window: any) -> bool:
        """
        Detect if we've reached the end of the server list
        Note: max_rows is already the valid count (total - 1), so we check >= max_rows
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            True if at end of list, False otherwise
        """
        # If we've reached max_rows (which is already valid_count), we're at the end
        # max_rows is 0-based valid count, so if current_row >= max_rows, we're done
        if self.max_rows > 0 and self.current_row >= self.max_rows:
            return True
        
        return False
    
    def server_discovery(self) -> bool:
        """
        New login flow:
        1. Navigate to "Open an Account"
        2. Enter and insert server name
        3. Wait until more than 2 items appear (if only 1 after 60s, cancel)
        4. If more than 2 items: Press Escape 3 times, then Alt+F, then 7x down arrow, then Enter
        5. Look for window with title "MetaTrader 4" and log its content
        
        Returns:
            True if login successful, False otherwise
        """
        print("\n=== Starting New MT4 Login Flow ===")
        sys.stdout.flush()
        
        # Step 1: Navigate to server window
        if not self.navigate_to_server_window():
            return False
        
        # Get window reference
        window = self.find_window_by_title("Open an Account|Open Account|Abrir una cuenta", timeout=5)
        if not window:
            print("[ERROR] Could not get window reference")
            sys.stdout.flush()
            return False
        
        # Step 2: Inject server and trigger search
        if not self.inject_server_and_trigger_search():
            return False
        
        # Step 3: Wait for server list to load (more than 2 items, 60 second timeout)
        if not self.wait_for_server_list_to_load(window, timeout=60):
            print("[ERROR] Server list did not load. No servers found or broker does not exist. Cancelling.")
            sys.stdout.flush()
            return False
        
        # Step 4: If we have more than 2 items, proceed with the new flow
        print("\n[Step 4] Server list loaded with more than 2 items. Proceeding with new login flow...")
        sys.stdout.flush()
        
        # Step 4a: Press Escape 3 times (no delays)
        # - First escape: exit list selection
        # - Second escape: close server window
        # - Third escape: close another popup
        print("[Step 4a] Pressing Escape 3 times (no delays)...")
        sys.stdout.flush()
        pyautogui.press('escape')
        pyautogui.press('escape')
        pyautogui.press('escape')
        
        # Step 4b: Press Alt+F
        print("[Step 4b] Pressing Alt+F...")
        sys.stdout.flush()
        pyautogui.hotkey('alt', 'f')
        
        # Step 4c: Press down arrow 7 times (no delays between presses)
        print("[Step 4c] Pressing down arrow 7 times (no delays)...")
        sys.stdout.flush()
        for i in range(9):
            pyautogui.press('down')
        
        # Step 4d: Press Enter
        print("[Step 4d] Pressing Enter...")
        sys.stdout.flush()
        pyautogui.press('enter')
        
        # Step 5: Look for window with title "MetaTrader 4"
        print("[Step 5] Looking for window with title 'MetaTrader 4'...")
        sys.stdout.flush()
        mt4_window = self.find_window_by_title("MetaTrader 4", timeout=10)
        
        if not mt4_window:
            print("[ERROR] Window with title 'MetaTrader 4' not found")
            sys.stdout.flush()
            return False
        
        print("[OK] Found window with title 'MetaTrader 4'")
        sys.stdout.flush()
        
        # Step 6: Log the content of the window
        print("\n[Step 6] Logging window content...")
        print("=" * 80)
        sys.stdout.flush()
        
        try:
            # Get window text/content
            window_text = mt4_window.window_text()
            print(f"[WINDOW CONTENT] Window Title: {mt4_window.window_text()}")
            print(f"[WINDOW CONTENT] Window Class: {mt4_window.class_name()}")
            print(f"[WINDOW CONTENT] Window Handle: {mt4_window.handle}")
            sys.stdout.flush()
            
            # Get all descendants and their text
            try:
                descendants = mt4_window.descendants()
                print(f"[WINDOW CONTENT] Total descendants: {len(descendants)}")
                sys.stdout.flush()
                
                for i, control in enumerate(descendants[:50]):  # Limit to first 50
                    try:
                        control_text = control.window_text()
                        control_class = control.class_name()
                        if control_text or control_class:
                            print(f"[WINDOW CONTENT] Control [{i}]: Class='{control_class}', Text='{control_text}'")
                            sys.stdout.flush()
                    except:
                        pass
                
                # Get all ComboBox controls and their items
                print("\n[WINDOW CONTENT] === Getting ComboBox contents ===")
                sys.stdout.flush()
                comboboxes = mt4_window.descendants(class_name="ComboBox")
                print(f"[WINDOW CONTENT] Found {len(comboboxes)} ComboBox controls")
                sys.stdout.flush()
                
                server_combo = None
                server_items = []
                
                for i, combo in enumerate(comboboxes):
                    try:
                        combo_text = combo.window_text()
                        print(f"\n[WINDOW CONTENT] ComboBox [{i}]:")
                        print(f"[WINDOW CONTENT]   Current Text: '{combo_text}'")
                        sys.stdout.flush()
                        
                        # Try to get all items from the ComboBox
                        items = None
                        try:
                            # Method 1: Try item_texts()
                            items = combo.item_texts()
                            if items:
                                print(f"[WINDOW CONTENT]   Items (item_texts()): {len(items)} items")
                                for idx, item in enumerate(items):
                                    print(f"[WINDOW CONTENT]     [{idx}] '{item}'")
                                sys.stdout.flush()
                        except Exception as e1:
                            try:
                                # Method 2: Try items()
                                items_objs = combo.items()
                                if items_objs:
                                    items = []
                                    print(f"[WINDOW CONTENT]   Items (items()): {len(items_objs)} items")
                                    for idx, item in enumerate(items_objs):
                                        try:
                                            item_text = item.window_text()
                                            items.append(item_text)
                                            print(f"[WINDOW CONTENT]     [{idx}] '{item_text}'")
                                        except:
                                            print(f"[WINDOW CONTENT]     [{idx}] (could not get text)")
                                    sys.stdout.flush()
                            except Exception as e2:
                                try:
                                    # Method 3: Try to expand and get items
                                    combo.expand()
                                    items = combo.item_texts()
                                    if items:
                                        print(f"[WINDOW CONTENT]   Items (after expand): {len(items)} items")
                                        for idx, item in enumerate(items):
                                            print(f"[WINDOW CONTENT]     [{idx}] '{item}'")
                                        sys.stdout.flush()
                                    combo.collapse()
                                except Exception as e3:
                                    print(f"[WINDOW CONTENT]   Could not get items: item_texts()={e1}, items()={e2}, expand()={e3}")
                                    sys.stdout.flush()
                        
                        # If this ComboBox has items and looks like a server ComboBox, save it
                        if items and len(items) > 1:
                            # This is likely the server ComboBox
                            server_combo = combo
                            server_items = items
                            print(f"[WINDOW CONTENT]   Identified as server ComboBox with {len(items)} items")
                            sys.stdout.flush()
                        
                    except Exception as e:
                        print(f"[WINDOW CONTENT]   Error processing ComboBox [{i}]: {e}")
                        sys.stdout.flush()
                
                # Step 7: Write server name directly in the ComboBox input
                if server_combo:
                    print(f"\n[Step 7] Writing server name directly in ComboBox: '{self.server}'")
                    sys.stdout.flush()
                    
                    try:
                        # Focus the combobox and write the server name directly
                        server_combo.set_focus()
                        time.sleep(0.2)
                        pyautogui.hotkey('ctrl', 'a')  # Select all existing text
                        time.sleep(0.1)
                        pyautogui.write(self.server, interval=0.05)
                        print(f"[OK] Server name written in ComboBox: '{self.server}'")
                        sys.stdout.flush()
                    except Exception as e:
                        print(f"[ERROR] Could not write server name in ComboBox: {e}")
                        sys.stdout.flush()
                        return False
                else:
                    print(f"[ERROR] Could not find server ComboBox")
                    sys.stdout.flush()
                    return False
                
                # Step 8: Fill login and password fields
                print(f"\n[Step 8] Filling login and password fields...")
                sys.stdout.flush()
                
                # Find login field (Edit or ComboBox)
                login_field = None
                try:
                    # Try to find Edit field for login (usually the first Edit after the Login label)
                    edits = mt4_window.descendants(class_name="Edit")
                    if edits and len(edits) > 0:
                        login_field = edits[0]  # First Edit is usually login
                        print(f"[INFO] Found login Edit field")
                        sys.stdout.flush()
                except:
                    pass
                
                if not login_field:
                    # Try ComboBox for login
                    try:
                        login_combos = [c for c in comboboxes if c != server_combo]
                        if login_combos:
                            login_field = login_combos[0]
                            print(f"[INFO] Found login ComboBox field")
                            sys.stdout.flush()
                    except:
                        pass
                
                if login_field:
                    try:
                        login_field.set_focus()
                        pyautogui.hotkey('ctrl', 'a')
                        pyautogui.write(self.login_number, interval=0.05)
                        print(f"[OK] Login field filled: {self.login_number}")
                        sys.stdout.flush()
                    except Exception as e:
                        print(f"[ERROR] Could not fill login field: {e}")
                        sys.stdout.flush()
                        return False
                else:
                    print(f"[ERROR] Could not find login field")
                    sys.stdout.flush()
                    return False
                
                # Find password field (Edit)
                password_field = None
                try:
                    edits = mt4_window.descendants(class_name="Edit")
                    if edits and len(edits) > 1:
                        password_field = edits[1]  # Second Edit is usually password
                        print(f"[INFO] Found password Edit field")
                        sys.stdout.flush()
                except:
                    pass
                
                if password_field:
                    try:
                        password_field.set_focus()
                        pyautogui.hotkey('ctrl', 'a')
                        pyautogui.write(self.password, interval=0.05)
                        print(f"[OK] Password field filled")
                        sys.stdout.flush()
                    except Exception as e:
                        print(f"[ERROR] Could not fill password field: {e}")
                        sys.stdout.flush()
                        return False
                else:
                    print(f"[ERROR] Could not find password field")
                    sys.stdout.flush()
                    return False
                
                # Step 9: Press Login button
                print(f"\n[Step 9] Pressing Login button...")
                sys.stdout.flush()
                try:
                    login_button = mt4_window.child_window(title="Login", control_type="Button")
                    if login_button.exists():
                        login_button.click()
                        print(f"[OK] Login button clicked")
                        sys.stdout.flush()
                    else:
                        # Fallback: try to find by text
                        buttons = mt4_window.descendants(class_name="Button")
                        for btn in buttons:
                            try:
                                if btn.window_text().lower() == "login":
                                    btn.click()
                                    print(f"[OK] Login button clicked (by text)")
                                    sys.stdout.flush()
                                    break
                            except:
                                pass
                except Exception as e:
                    print(f"[ERROR] Could not click Login button: {e}")
                    sys.stdout.flush()
                    return False
                
                # Step 10: Press Ctrl+E after login
                print(f"\n[Step 10] Pressing Ctrl+E after login...")
                sys.stdout.flush()
                time.sleep(0.5)  # Small delay to ensure login is processed
                pyautogui.hotkey('ctrl', 'e')
                print(f"[OK] Ctrl+E pressed")
                sys.stdout.flush()
                
            except Exception as e:
                print(f"[WINDOW CONTENT] Error getting descendants: {e}")
                sys.stdout.flush()
            
        except Exception as e:
            print(f"[ERROR] Error logging window content: {e}")
            import traceback
            traceback.print_exc()
            sys.stdout.flush()
        
        print("=" * 80)
        print("[INFO] Window content logged. Waiting for next instructions...")
        sys.stdout.flush()
        
        # For now, return True to indicate we found the window
        # The actual login validation will be done in the next step
        return True
    
    def login(self) -> bool:
        """
        Perform MT4 login using server discovery
        
        Returns:
            True if login successful, False otherwise
        """
        print("\n=== Starting MT4 Login Process ===")
        sys.stdout.flush()
        
        try:
            return self.server_discovery()
        except Exception as e:
            print(f"\n[ERROR] Error during MT4 login: {e}")
            import traceback
            traceback.print_exc()
            sys.stdout.flush()
            sys.stderr.flush()
            return False


def main():
    """Main entry point for MT4 login script"""
    try:
        # Force unbuffered output
        sys.stdout.reconfigure(line_buffering=True) if hasattr(sys.stdout, 'reconfigure') else None
        sys.stderr.reconfigure(line_buffering=True) if hasattr(sys.stderr, 'reconfigure') else None
        
        print("=" * 60, flush=True)
        print("MT4 Login Script Starting", flush=True)
        print("=" * 60, flush=True)
        sys.stdout.flush()
        sys.stderr.flush()
        
        if len(sys.argv) < 5:
            print("[ERROR] Usage: python mt4.py <mt_path> <login> <password> <server>", flush=True)
            sys.stdout.flush()
            sys.exit(1)
        
        mt_path = sys.argv[1]
        login = sys.argv[2]
        password = sys.argv[3]
        server = sys.argv[4]
        
        print(f"Arguments received:", flush=True)
        print(f"  mt_path: {mt_path}", flush=True)
        print(f"  login: {login}", flush=True)
        print(f"  password: {'*' * len(password)}", flush=True)
        print(f"  server: {server}", flush=True)
        sys.stdout.flush()
        
        login_automation = MT4Login(mt_path, login, password, server)
        print("Login automation object created, calling run()...", flush=True)
        sys.stdout.flush()
        
        success = login_automation.run()
        
        print("=" * 60, flush=True)
        if success:
            print("[OK] Login script completed successfully", flush=True)
        else:
            print("[ERROR] Login script failed", flush=True)
        print("=" * 60, flush=True)
        sys.stdout.flush()
        sys.stderr.flush()
        
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"[ERROR] Fatal error in main(): {e}", flush=True)
        import traceback
        traceback.print_exc(file=sys.stdout)
        sys.stdout.flush()
        sys.stderr.flush()
        sys.exit(1)


if __name__ == "__main__":
    main()
