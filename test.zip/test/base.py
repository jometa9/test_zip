"""
Base module for MetaTrader login automation using UI automation
Uses:
- pywinauto → "¿Dónde está MetaTrader?"
- pyautogui → "Haz click aquí y navega con botones"
"""

import time
import sys
import os
from typing import Optional, Tuple, List, Dict, Any
from pathlib import Path

# Fix encoding for Windows console (cp1252) - use environment variable instead
# This is safer when running from Node.js as it doesn't replace sys.stdout/stderr
if sys.platform == 'win32':
    os.environ['PYTHONIOENCODING'] = 'utf-8'

try:
    from pywinauto import Application, findwindows
    from pywinauto.findwindows import ElementNotFoundError
except ImportError:
    print("ERROR: pywinauto not installed. Install with: pip install pywinauto")
    sys.exit(1)

try:
    import win32gui
    import win32con
    WIN32_AVAILABLE = True
except ImportError:
    WIN32_AVAILABLE = False
    print("[WARNING] win32gui not available. Some ListView text reading methods may not work.")

try:
    import pyautogui
except ImportError:
    print("ERROR: pyautogui not installed. Install with: pip install pyautogui")
    sys.exit(1)

try:
    import psutil
except ImportError:
    # psutil is optional, only needed for process-based window finding
    psutil = None


class MetaTraderLoginBase:
    """Base class for MetaTrader login automation"""
    
    def __init__(self, mt_path: str, login: str, password: str, server: str, timeout: int = 60):
        """
        Initialize login automation
        
        Args:
            mt_path: Path to MetaTrader installation
            login: Account login number
            password: Account password
            server: Server name
            timeout: Timeout in seconds for operations
        """
        self.mt_path = Path(mt_path)
        self.login_number = str(login)  # Renamed to avoid conflict with login() method
        self.password = str(password)
        self.server = str(server)
        self.timeout = timeout
        self.app: Optional[Application] = None
        self.main_window = None
        
        # Configure pyautogui
        pyautogui.FAILSAFE = False
        pyautogui.PAUSE = 0.5
    
    def find_metatrader_window(self, window_title_pattern: str) -> bool:
        """
        Find MetaTrader window using pywinauto
        
        Args:
            window_title_pattern: Pattern to match window title (e.g., "MetaTrader" or "terminal")
            
        Returns:
            True if window found, False otherwise
        """
        try:
            # Try multiple search strategies
            # Strategy 1: Regex pattern match
            try:
                windows = findwindows.find_windows(title_re=window_title_pattern)
                if windows:
                    self.app = Application(backend="win32").connect(handle=windows[0])
                    self.main_window = self.app.top_window()
                    print(f"[OK] Found MetaTrader window: {self.main_window.window_text()}")
                    return True
            except:
                pass
            
            # Strategy 2: Search all windows for partial matches
            all_windows = findwindows.find_windows()
            search_terms = window_title_pattern.split('|')
            
            for hwnd in all_windows:
                try:
                    window_text = findwindows.find_element(handle=hwnd).window_text()
                    window_text_lower = window_text.lower()
                    
                    # Check if any search term matches
                    for term in search_terms:
                        if term.lower() in window_text_lower:
                            # Additional check: make sure it's actually MetaTrader
                            if 'metatrader' in window_text_lower or 'terminal' in window_text_lower or 'mt4' in window_text_lower or 'mt5' in window_text_lower:
                                self.app = Application(backend="win32").connect(handle=hwnd)
                                self.main_window = self.app.top_window()
                                print(f"[OK] Found MetaTrader window: {window_text}")
                                return True
                except:
                    continue
                
        except ElementNotFoundError:
            pass
        except Exception as e:
            print(f"[ERROR] Error finding MetaTrader window: {e}")
        
        return False
    
    def wait_for_window(self, window_title_pattern: str, timeout: Optional[int] = None) -> bool:
        """
        Wait for MetaTrader window to appear
        
        Args:
            window_title_pattern: Pattern to match window title
            timeout: Timeout in seconds (uses self.timeout if None)
            
        Returns:
            True if window found, False if timeout
        """
        timeout = timeout or self.timeout
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            if self.find_metatrader_window(window_title_pattern):
                return True
            time.sleep(1)
        
        print(f"[ERROR] Timeout waiting for MetaTrader window (>{timeout}s)")
        return False
    
    def find_window_by_title(self, title_pattern: str, timeout: Optional[int] = None) -> Optional[any]:
        """
        Find and return a window by title pattern using pywinauto
        
        Args:
            title_pattern: Pattern to match window title (regex or partial match)
            timeout: Timeout in seconds (uses self.timeout if None)
            
        Returns:
            Window object if found, None otherwise
        """
        timeout = timeout or self.timeout
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                # Try exact match first
                windows = findwindows.find_windows(title=title_pattern)
                if windows:
                    app = Application(backend="win32").connect(handle=windows[0])
                    window = app.window(handle=windows[0])
                    print(f"[OK] Found window by exact title: {title_pattern}")
                    return window
                
                # Try regex pattern
                windows = findwindows.find_windows(title_re=title_pattern)
                if windows:
                    app = Application(backend="win32").connect(handle=windows[0])
                    window = app.window(handle=windows[0])
                    print(f"[OK] Found window by title pattern: {title_pattern}")
                    return window
                
                # Try case-insensitive partial match
                all_windows = findwindows.find_windows()
                for hwnd in all_windows:
                    try:
                        window_text = findwindows.find_element(handle=hwnd).window_text()
                        if title_pattern.lower() in window_text.lower():
                            app = Application(backend="win32").connect(handle=hwnd)
                            window = app.window(handle=hwnd)
                            print(f"[OK] Found window by partial match: '{window_text}' (searching for: {title_pattern})")
                            return window
                    except:
                        pass
                        
            except Exception as e:
                pass
            
            time.sleep(0.5)
        
        print(f"[ERROR] Timeout waiting for window with title pattern: {title_pattern}")
        return None
    
    def activate_window(self, window: any) -> bool:
        """
        Activate and bring a window to foreground
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            True if successful, False otherwise
        """
        try:
            window.set_focus()  # Just focus, don't move
            window.restore()  # Restore if minimized (this doesn't move it)
            time.sleep(0.5)
            print(f"[OK] Activated window: {window.window_text()}")
            return True
        except Exception as e:
            print(f"[ERROR] Error activating window: {e}")
            return False
    
    
    def click_at_position(self, x: int, y: int, button: str = 'left', clicks: int = 1):
        """
        Click at position using pyautogui
        
        Args:
            x: X coordinate
            y: Y coordinate
            button: 'left' or 'right'
            clicks: Number of clicks
        """
        try:
            pyautogui.click(x, y, button=button, clicks=clicks)
            print(f"[OK] Clicked at ({x}, {y})")
            time.sleep(0.5)
        except Exception as e:
            print(f"Error clicking at ({x}, {y}): {e}")
    
    def type_text(self, text: str, interval: float = 0.1):
        """
        Type text using pyautogui
        
        Args:
            text: Text to type
            interval: Delay between keystrokes
        """
        try:
            pyautogui.write(text, interval=interval)
            print(f"[OK] Typed text: {'*' * len(text) if 'password' in text.lower() else text[:10]}...")
            time.sleep(0.5)
        except Exception as e:
            print(f"Error typing text: {e}")
    
    def press_key(self, key: str, presses: int = 1):
        """
        Press key using pyautogui
        
        Args:
            key: Key to press (e.g., 'enter', 'tab', 'escape')
            presses: Number of times to press
        """
        try:
            pyautogui.press(key, presses=presses)
            print(f"[OK] Pressed key: {key}")
            time.sleep(0.5)
        except Exception as e:
            print(f"Error pressing key {key}: {e}")
    
    def scroll_down(self, clicks: int = 3):
        """
        Scroll down in the current window
        
        Args:
            clicks: Number of scroll clicks (default: 3)
        """
        try:
            pyautogui.scroll(-clicks * 120)  # Negative for scroll down, 120 pixels per click
            time.sleep(0.2)
            print(f"[OK] Scrolled down ({clicks} clicks)")
        except Exception as e:
            print(f"[ERROR] Error scrolling: {e}")
    
    def scroll_up(self, clicks: int = 3):
        """
        Scroll up in the current window
        
        Args:
            clicks: Number of scroll clicks (default: 3)
        """
        try:
            pyautogui.scroll(clicks * 120)  # Positive for scroll up, 120 pixels per click
            time.sleep(0.2)
            print(f"[OK] Scrolled up ({clicks} clicks)")
        except Exception as e:
            print(f"[ERROR] Error scrolling up: {e}")
    
    def get_window_controls_count(self, window: any, control_type: str = None) -> int:
        """
        Get count of controls in a window
        
        Args:
            window: Window object from pywinauto
            control_type: Optional control type to filter (e.g., "Button", "Edit", "ListItem")
            
        Returns:
            Number of controls found
        """
        try:
            if control_type:
                controls = window.descendants(control_type=control_type)
            else:
                controls = window.descendants()
            return len(controls)
        except Exception as e:
            print(f"[DEBUG] Error getting controls count: {e}")
            return 0
    
    def debug_window_info(self, window: any) -> None:
        """
        Debug function to capture and print all window information
        
        Args:
            window: Window object from pywinauto
        """
        print("\n" + "=" * 80)
        print("[DEBUG] ========== WINDOW INFORMATION ==========")
        print("=" * 80)
        sys.stdout.flush()
        
        try:
            # Window basic info
            print(f"\n[DEBUG] Window Title: {window.window_text()}")
            print(f"[DEBUG] Window Class: {window.class_name()}")
            print(f"[DEBUG] Window Handle: {window.handle}")
            sys.stdout.flush()
            
            try:
                rect = window.rectangle()
                print(f"[DEBUG] Window Rectangle: left={rect.left}, top={rect.top}, right={rect.right}, bottom={rect.bottom}")
                print(f"[DEBUG] Window Size: width={rect.width()}, height={rect.height()}")
            except:
                print(f"[DEBUG] Could not get window rectangle")
            sys.stdout.flush()
            
            # Get all descendants
            print(f"\n[DEBUG] --- All Descendants ---")
            try:
                all_descendants = window.descendants()
                print(f"[DEBUG] Total descendants: {len(all_descendants)}")
                sys.stdout.flush()
                
                # Group by control type
                control_types = {}
                for i, control in enumerate(all_descendants):
                    try:
                        ctrl_type = control.element_info.control_type if hasattr(control, 'element_info') else "Unknown"
                        if ctrl_type not in control_types:
                            control_types[ctrl_type] = []
                        control_types[ctrl_type].append(control)
                    except:
                        pass
                
                print(f"\n[DEBUG] Control types found: {len(control_types)}")
                for ctrl_type, controls in sorted(control_types.items()):
                    print(f"[DEBUG]   - {ctrl_type}: {len(controls)} controls")
                sys.stdout.flush()
                
                # Detailed info for each control type
                print(f"\n[DEBUG] --- Detailed Control Information ---")
                for ctrl_type, controls in sorted(control_types.items()):
                    print(f"\n[DEBUG] === {ctrl_type} ({len(controls)} found) ===")
                    for i, control in enumerate(controls[:10]):  # Limit to first 10 of each type
                        try:
                            info = {}
                            if hasattr(control, 'window_text'):
                                try:
                                    info['text'] = control.window_text()
                                except:
                                    info['text'] = "N/A"
                            if hasattr(control, 'class_name'):
                                try:
                                    info['class'] = control.class_name()
                                except:
                                    info['class'] = "N/A"
                            if hasattr(control, 'element_info'):
                                try:
                                    info['control_type'] = control.element_info.control_type
                                except:
                                    pass
                            try:
                                rect = control.rectangle()
                                info['rect'] = f"({rect.left},{rect.top})-({rect.right},{rect.bottom})"
                            except:
                                info['rect'] = "N/A"
                            
                            print(f"[DEBUG]   [{i}] {info}")
                        except Exception as e:
                            print(f"[DEBUG]   [{i}] Error getting info: {e}")
                    if len(controls) > 10:
                        print(f"[DEBUG]   ... and {len(controls) - 10} more")
                    sys.stdout.flush()
                
            except Exception as e:
                print(f"[DEBUG] Error getting descendants: {e}")
                import traceback
                traceback.print_exc()
                sys.stdout.flush()
            
            # Specific searches for List controls
            print(f"\n[DEBUG] --- List Controls Search ---")
            try:
                lists = window.descendants(control_type="List")
                print(f"[DEBUG] Found {len(lists)} List controls")
                for i, list_ctrl in enumerate(lists):
                    try:
                        print(f"[DEBUG]   List [{i}]:")
                        print(f"[DEBUG]     Text: {list_ctrl.window_text()}")
                        print(f"[DEBUG]     Class: {list_ctrl.class_name()}")
                        try:
                            count = list_ctrl.item_count()
                            print(f"[DEBUG]     Item Count: {count}")
                        except Exception as e:
                            print(f"[DEBUG]     Item Count: Error - {e}")
                        try:
                            rect = list_ctrl.rectangle()
                            print(f"[DEBUG]     Rectangle: {rect}")
                        except:
                            pass
                    except Exception as e:
                        print(f"[DEBUG]     Error: {e}")
                sys.stdout.flush()
            except Exception as e:
                print(f"[DEBUG] Error searching for List controls: {e}")
                sys.stdout.flush()
            
            # Search for ListItem controls
            print(f"\n[DEBUG] --- ListItem Controls Search ---")
            try:
                list_items = window.descendants(control_type="ListItem")
                print(f"[DEBUG] Found {len(list_items)} ListItem controls")
                for i, item in enumerate(list_items[:20]):  # Limit to first 20
                    try:
                        print(f"[DEBUG]   ListItem [{i}]:")
                        print(f"[DEBUG]     Text: {item.window_text()}")
                        print(f"[DEBUG]     Class: {item.class_name()}")
                        try:
                            rect = item.rectangle()
                            print(f"[DEBUG]     Rectangle: {rect}")
                        except:
                            pass
                    except Exception as e:
                        print(f"[DEBUG]     Error: {e}")
                if len(list_items) > 20:
                    print(f"[DEBUG]   ... and {len(list_items) - 20} more ListItems")
                sys.stdout.flush()
            except Exception as e:
                print(f"[DEBUG] Error searching for ListItem controls: {e}")
                sys.stdout.flush()
            
            # Search for SysListView32 (Windows ListView control)
            print(f"\n[DEBUG] --- SysListView32 (Windows ListView) Search ---")
            try:
                listviews = window.descendants(class_name="SysListView32")
                print(f"[DEBUG] Found {len(listviews)} SysListView32 controls")
                for i, lv in enumerate(listviews):
                    try:
                        print(f"[DEBUG]   ListView [{i}]:")
                        print(f"[DEBUG]     Text: {lv.window_text()}")
                        print(f"[DEBUG]     Class: {lv.class_name()}")
                        try:
                            rect = lv.rectangle()
                            print(f"[DEBUG]     Rectangle: {rect}")
                        except:
                            pass
                        
                        # Try to get item count using ListView methods
                        try:
                            # Method 1: item_count()
                            count = lv.item_count()
                            print(f"[DEBUG]     Item Count (item_count()): {count}")
                        except Exception as e:
                            print(f"[DEBUG]     Item Count (item_count()): Error - {e}")
                        
                        try:
                            # Method 2: Get item texts by iterating rows
                            item_count = lv.item_count()
                            if item_count > 0:
                                print(f"[DEBUG]     Trying to get texts for {item_count} items...")
                                sample_texts = []
                                for row_idx in range(min(5, item_count)):
                                    try:
                                        row_texts = lv.item_texts(row_idx)
                                        if isinstance(row_texts, (list, tuple)):
                                            display_text = " | ".join(str(t).strip() for t in row_texts if str(t).strip())
                                        else:
                                            display_text = str(row_texts).strip()
                                        sample_texts.append(display_text)
                                        print(f"[DEBUG]       Row [{row_idx}]: {display_text}")
                                    except Exception as e:
                                        print(f"[DEBUG]       Row [{row_idx}]: Error - {e}")
                                if item_count > 5:
                                    print(f"[DEBUG]       ... and {item_count - 5} more rows")
                        except Exception as e:
                            print(f"[DEBUG]     Items (item_texts by row): Error - {e}")
                        
                        try:
                            # Method 3: Try get_item() for each row
                            item_count = lv.item_count()
                            if item_count > 0:
                                print(f"[DEBUG]     Trying get_item() for first 3 rows...")
                                for row_idx in range(min(3, item_count)):
                                    try:
                                        item = lv.get_item(row_idx)
                                        if item:
                                            # Try different methods to get text
                                            try:
                                                text = item.text()
                                                print(f"[DEBUG]       Row [{row_idx}] get_item().text(): {text}")
                                            except:
                                                pass
                                            try:
                                                text = item.texts()
                                                print(f"[DEBUG]       Row [{row_idx}] get_item().texts(): {text}")
                                            except:
                                                pass
                                            try:
                                                # Try to get subitems (columns)
                                                subitems = item.subitems()
                                                print(f"[DEBUG]       Row [{row_idx}] get_item().subitems(): {subitems}")
                                            except:
                                                pass
                                    except Exception as e:
                                        print(f"[DEBUG]       Row [{row_idx}] get_item() error: {e}")
                        except Exception as e:
                            print(f"[DEBUG]     get_item() method: Error - {e}")
                        
                        try:
                            # Method 4: Try items() method
                            items = lv.items()
                            print(f"[DEBUG]     Items found (items()): {len(items)}")
                            if items:
                                print(f"[DEBUG]     First 3 items details:")
                                for idx, item in enumerate(items[:3]):
                                    try:
                                        # Try different methods
                                        methods_tried = []
                                        try:
                                            text = item.text()
                                            methods_tried.append(f"text()={text}")
                                        except:
                                            pass
                                        try:
                                            texts = item.texts()
                                            methods_tried.append(f"texts()={texts}")
                                        except:
                                            pass
                                        try:
                                            subitems = item.subitems()
                                            methods_tried.append(f"subitems()={subitems}")
                                        except:
                                            pass
                                        if methods_tried:
                                            print(f"[DEBUG]       [{idx}] {', '.join(methods_tried)}")
                                        else:
                                            print(f"[DEBUG]       [{idx}] (no methods worked)")
                                    except:
                                        print(f"[DEBUG]       [{idx}] (error getting item details)")
                        except Exception as e:
                            print(f"[DEBUG]     Items (items()): Error - {e}")
                        
                        # Try to get column headers
                        try:
                            headers = lv.column_headers()
                            if headers:
                                print(f"[DEBUG]     Column Headers: {headers}")
                        except:
                            pass
                        
                        # Try Win32 API as last resort
                        try:
                            listview_handle = lv.handle
                            if listview_handle and WIN32_AVAILABLE:
                                print(f"[DEBUG]     Trying Win32 API directly (handle: {listview_handle})...")
                                win32_texts = self.get_listview_texts_win32(listview_handle, min(5, item_count))
                                if win32_texts:
                                    print(f"[DEBUG]     Win32 API results (first 5 rows):")
                                    for idx, text in enumerate(win32_texts[:5]):
                                        print(f"[DEBUG]       Row [{idx}]: {text}")
                        except Exception as e:
                            print(f"[DEBUG]     Win32 API test error: {e}")
                            
                    except Exception as e:
                        print(f"[DEBUG]     Error processing ListView: {e}")
                        import traceback
                        traceback.print_exc()
                sys.stdout.flush()
            except Exception as e:
                print(f"[DEBUG] Error searching for SysListView32: {e}")
                import traceback
                traceback.print_exc()
                sys.stdout.flush()
            
            # Search for other potential list-like controls
            print(f"\n[DEBUG] --- Other List-like Controls ---")
            for ctrl_type in ["DataGrid", "Table", "TreeView", "TreeViewItem"]:
                try:
                    controls = window.descendants(control_type=ctrl_type)
                    if controls:
                        print(f"[DEBUG] Found {len(controls)} {ctrl_type} controls")
                        for i, ctrl in enumerate(controls[:5]):
                            try:
                                print(f"[DEBUG]   [{i}] Text: {ctrl.window_text()}, Class: {ctrl.class_name()}")
                            except:
                                pass
                except:
                    pass
            sys.stdout.flush()
            
        except Exception as e:
            print(f"[DEBUG] Error in debug_window_info: {e}")
            import traceback
            traceback.print_exc()
            sys.stdout.flush()
        
        print("\n" + "=" * 80)
        print("[DEBUG] ========== END WINDOW INFORMATION ==========")
        print("=" * 80 + "\n")
        sys.stdout.flush()
    
    def get_listview_texts_win32(self, listview_handle: int, item_count: int) -> List[str]:
        """
        Get texts from ListView using Windows API directly via ctypes
        
        Args:
            listview_handle: Handle to the ListView control
            item_count: Number of items in the list
            
        Returns:
            List of item texts
        """
        if not WIN32_AVAILABLE:
            return []
        
        texts = []
        try:
            import ctypes
            from ctypes import wintypes, Structure, c_int, c_uint, byref, c_void_p, c_wchar_p
            
            # Constants
            LVM_GETITEMTEXT = 0x1073
            LVIF_TEXT = 0x0001
            MAX_TEXT_LENGTH = 512
            
            # Define LVITEM structure (Unicode version)
            class LVITEM(Structure):
                _fields_ = [
                    ("mask", c_uint),
                    ("iItem", c_int),
                    ("iSubItem", c_int),
                    ("state", c_uint),
                    ("stateMask", c_uint),
                    ("pszText", c_wchar_p),
                    ("cchTextMax", c_int),
                    ("iImage", c_int),
                    ("lParam", c_void_p),
                ]
            
            for row_index in range(item_count):
                row_texts = []
                
                # Try to get text from each column (up to 5 columns)
                for col_index in range(5):
                    try:
                        # Allocate buffer for text (Unicode)
                        text_buffer = ctypes.create_unicode_buffer(MAX_TEXT_LENGTH)
                        
                        # Create LVITEM structure
                        lv_item = LVITEM()
                        lv_item.mask = LVIF_TEXT
                        lv_item.iItem = row_index
                        lv_item.iSubItem = col_index
                        lv_item.pszText = ctypes.cast(text_buffer, c_wchar_p)
                        lv_item.cchTextMax = MAX_TEXT_LENGTH
                        
                        # Send message to get item text
                        result = win32gui.SendMessage(
                            listview_handle,
                            LVM_GETITEMTEXT,
                            row_index,
                            byref(lv_item)
                        )
                        
                        if result > 0:
                            text = text_buffer.value.strip()
                            if text:
                                row_texts.append(text)
                        else:
                            # If result is 0, this column doesn't exist or is empty
                            break
                            
                    except Exception as e:
                        # If we can't get this column, stop trying more columns
                        break
                
                if row_texts:
                    texts.append(" | ".join(row_texts))
                else:
                    texts.append("")
                    
        except Exception as e:
            print(f"[DEBUG] Error in get_listview_texts_win32: {e}")
            import traceback
            traceback.print_exc()
        
        return texts
    
    def get_list_items_texts(self, window: any) -> List[str]:
        """
        Get text of all items in a list control
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            List of item texts (each item may be a string or tuple/list for multi-column rows)
        """
        try:
            # First, try to find SysListView32 (Windows ListView control)
            listviews = window.descendants(class_name="SysListView32")
            if listviews:
                for lv in listviews:
                    try:
                        # Get item count first
                        item_count = lv.item_count()
                        if item_count == 0:
                            continue
                        
                        texts = []
                        got_texts = False
                        
                        # Iterate through each row and get its text
                        for row_index in range(item_count):
                            row_text = ""
                            try:
                                # Method 1: Try item_texts(row_index) - returns tuple/list of column texts
                                row_texts = lv.item_texts(row_index)
                                if row_texts:
                                    # If it's a tuple/list, join columns with " | "
                                    if isinstance(row_texts, (list, tuple)):
                                        # Filter out empty strings and join
                                        non_empty = [str(t).strip() for t in row_texts if str(t).strip()]
                                        if non_empty:
                                            row_text = " | ".join(non_empty)
                                            got_texts = True
                                    else:
                                        row_text = str(row_texts).strip()
                                        if row_text:
                                            got_texts = True
                            except:
                                try:
                                    # Method 2: Try get_item() and then methods
                                    item = lv.get_item(row_index)
                                    if item:
                                        # Try text()
                                        try:
                                            row_text = str(item.text()).strip()
                                            if row_text:
                                                got_texts = True
                                        except:
                                            # Try texts() - returns tuple of column texts
                                            try:
                                                item_texts = item.texts()
                                                if isinstance(item_texts, (list, tuple)):
                                                    non_empty = [str(t).strip() for t in item_texts if str(t).strip()]
                                                    if non_empty:
                                                        row_text = " | ".join(non_empty)
                                                        got_texts = True
                                                else:
                                                    row_text = str(item_texts).strip()
                                                    if row_text:
                                                        got_texts = True
                                            except:
                                                # Try subitems()
                                                try:
                                                    subitems = item.subitems()
                                                    if isinstance(subitems, (list, tuple)):
                                                        non_empty = [str(t).strip() for t in subitems if str(t).strip()]
                                                        if non_empty:
                                                            row_text = " | ".join(non_empty)
                                                            got_texts = True
                                                except:
                                                    pass
                                except:
                                    pass
                            
                            texts.append(row_text if row_text else "")
                        
                        # If we didn't get any texts using pywinauto methods, try Win32 API directly
                        if not got_texts or all(not t for t in texts):
                            try:
                                listview_handle = lv.handle
                                if listview_handle:
                                    print(f"[DEBUG] Pywinauto methods failed, trying Win32 API directly...")
                                    sys.stdout.flush()
                                    win32_texts = self.get_listview_texts_win32(listview_handle, item_count)
                                    if win32_texts and any(t for t in win32_texts):
                                        print(f"[DEBUG] Win32 API succeeded! Got {len([t for t in win32_texts if t])} non-empty texts")
                                        sys.stdout.flush()
                                        return win32_texts
                            except Exception as e:
                                print(f"[DEBUG] Win32 API also failed: {e}")
                                sys.stdout.flush()
                        
                        if texts:
                            return texts
                    except Exception as e:
                        print(f"[DEBUG] Error processing ListView in get_list_items_texts: {e}")
                        import traceback
                        traceback.print_exc()
                        continue
            
            # Try standard List controls
            lists = window.descendants(control_type="List")
            if lists:
                try:
                    # Try to get item texts from first list
                    items = lists[0].items()
                    texts = []
                    for item in items:
                        try:
                            texts.append(item.window_text())
                        except:
                            pass
                    if texts:
                        return texts
                except:
                    pass
            
            # Fallback: try ListItem controls
            list_items = window.descendants(control_type="ListItem")
            if list_items:
                texts = []
                for item in list_items:
                    try:
                        texts.append(item.window_text())
                    except:
                        pass
                return texts
            
            return []
        except Exception as e:
            print(f"[DEBUG] Error getting list items texts: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    def get_list_items_count(self, window: any) -> int:
        """
        Get count of items in a list control
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            Number of list items found
        """
        try:
            # First, try to find SysListView32 (Windows ListView control)
            # This is commonly used in Windows dialogs
            listviews = window.descendants(class_name="SysListView32")
            if listviews:
                for lv in listviews:
                    try:
                        # Method 1: Try item_count()
                        count = lv.item_count()
                        if count > 0:
                            print(f"[DEBUG] Found {count} items in SysListView32 using item_count()")
                            sys.stdout.flush()
                            return count
                    except:
                        pass
                    
                    try:
                        # Method 2: Try item_texts()
                        item_texts = lv.item_texts()
                        if item_texts:
                            print(f"[DEBUG] Found {len(item_texts)} items in SysListView32 using item_texts()")
                            sys.stdout.flush()
                            return len(item_texts)
                    except:
                        pass
                    
                    try:
                        # Method 3: Try items()
                        items = lv.items()
                        if items:
                            print(f"[DEBUG] Found {len(items)} items in SysListView32 using items()")
                            sys.stdout.flush()
                            return len(items)
                    except:
                        pass
            
            # Try to find list controls (standard UIA)
            lists = window.descendants(control_type="List")
            if lists:
                # Try to get item count from first list
                try:
                    count = lists[0].item_count()
                    if count > 0:
                        return count
                except:
                    pass
            
            # Fallback: try ListItem controls
            list_items = window.descendants(control_type="ListItem")
            if list_items:
                return len(list_items)
            
            return 0
        except Exception as e:
            print(f"[DEBUG] Error getting list items count: {e}")
            import traceback
            traceback.print_exc()
            sys.stdout.flush()
            return 0
    
    def detect_window_changes(self, window: any, check_interval: float = 1.0, timeout: float = 10.0) -> bool:
        """
        Detect if window content has changed by comparing control counts and list items
        
        Args:
            window: Window object from pywinauto
            check_interval: Time between checks in seconds
            timeout: Maximum time to wait for changes
            
        Returns:
            True if window changed, False if timeout
        """
        try:
            initial_controls_count = self.get_window_controls_count(window)
            initial_list_count = self.get_list_items_count(window)
            start_time = time.time()
            
            print(f"[INFO] Initial state: {initial_controls_count} controls, {initial_list_count} list items")
            sys.stdout.flush()
            
            while time.time() - start_time < timeout:
                time.sleep(check_interval)
                current_controls_count = self.get_window_controls_count(window)
                current_list_count = self.get_list_items_count(window)
                
                # Check if either controls or list items changed
                if current_controls_count != initial_controls_count or current_list_count != initial_list_count:
                    print(f"[OK] Window changed: controls {initial_controls_count} -> {current_controls_count}, list items {initial_list_count} -> {current_list_count}")
                    sys.stdout.flush()
                    return True
                
                elapsed = time.time() - start_time
                if int(elapsed) % 2 == 0:  # Log every 2 seconds
                    print(f"[INFO] Waiting for window changes... ({int(elapsed)}s elapsed)")
                    sys.stdout.flush()
            
            print(f"[INFO] No window changes detected after {timeout}s (may continue anyway)")
            sys.stdout.flush()
            return False
        except Exception as e:
            print(f"[ERROR] Error detecting window changes: {e}")
            sys.stdout.flush()
            return False
    
    def wait_for_button_enabled(self, window: any, button_text: str, timeout: int = 30) -> bool:
        """
        Wait for a button to be enabled in a window
        
        Args:
            window: Window object from pywinauto
            button_text: Text of the button to wait for
            timeout: Maximum time to wait in seconds
            
        Returns:
            True if button is enabled, False if timeout
        """
        try:
            start_time = time.time()
            print(f"[INFO] Waiting for button '{button_text}' to be enabled (timeout: {timeout}s)...")
            sys.stdout.flush()
            
            while time.time() - start_time < timeout:
                try:
                    # Try multiple methods to find buttons
                    buttons = []
                    
                    # Method 1: descendants with Button control type
                    try:
                        buttons = window.descendants(control_type="Button")
                    except:
                        pass
                    
                    # Method 2: If no buttons found, try all descendants and filter
                    if len(buttons) == 0:
                        try:
                            all_controls = window.descendants()
                            buttons = [ctrl for ctrl in all_controls if hasattr(ctrl, 'window_text')]
                        except:
                            pass
                    
                    # Method 3: Try child_window with Button
                    if len(buttons) == 0:
                        try:
                            btn = window.child_window(control_type="Button", title_re=f".*{button_text}.*")
                            if btn.exists():
                                buttons = [btn]
                        except:
                            pass
                    
                    for btn in buttons:
                        try:
                            if not hasattr(btn, 'window_text'):
                                continue
                            btn_text = btn.window_text().strip()
                            # Check if button text matches (case-insensitive)
                            if button_text.lower() in btn_text.lower() or btn_text.lower() in button_text.lower():
                                is_enabled = btn.is_enabled() if hasattr(btn, 'is_enabled') else False
                                if is_enabled:
                                    print(f"[OK] Button '{button_text}' is now enabled")
                                    sys.stdout.flush()
                                    return True
                        except Exception as btn_err:
                            continue
                    
                    elapsed = time.time() - start_time
                    if int(elapsed) % 2 == 0 and int(elapsed) > 0:
                        print(f"[INFO] Still waiting for button '{button_text}'... ({int(elapsed)}s elapsed)")
                        sys.stdout.flush()
                    
                    time.sleep(0.5)
                except Exception as e:
                    print(f"[DEBUG] Error finding buttons, retrying...: {e}")
                    sys.stdout.flush()
                    time.sleep(0.5)
                    continue
            
            print(f"[ERROR] Timeout waiting for button '{button_text}' to be enabled after {timeout}s")
            sys.stdout.flush()
            return False
        except Exception as e:
            print(f"[ERROR] Error waiting for button: {e}")
            import traceback
            traceback.print_exc()
            sys.stdout.flush()
            return False
    
    def find_input_controls(self, window: any) -> List[Any]:
        """
        Find all input controls (Edit, CheckBox) in a window
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            List of input controls
        """
        try:
            inputs = []
            # Find Edit controls
            try:
                edits = window.descendants(control_type="Edit")
                inputs.extend(edits)
            except:
                pass
            
            # Find CheckBox controls
            try:
                checkboxes = window.descendants(control_type="CheckBox")
                inputs.extend(checkboxes)
            except:
                pass
            
            return inputs
        except Exception as e:
            print(f"[ERROR] Error finding input controls: {e}")
            return []
    
    def fill_login_form(self, window: any, login: str, password: str) -> bool:
        """
        Fill login form by finding input controls and filling them using pyautogui
        
        Args:
            window: Window object from pywinauto
            login: Login number
            password: Password
            
        Returns:
            True if form filled successfully, False otherwise
        """
        try:
            inputs = self.find_input_controls(window)
            if len(inputs) < 2:
                print(f"[ERROR] Expected at least 2 input controls, found {len(inputs)}")
                return False
            
            # First input: checkbox (if exists) or login
            # Second input: login
            # Third input: password
            
            input_index = 0
            
            # Check if first is checkbox
            if len(inputs) > 0:
                try:
                    first_control_type = inputs[0].element_info.control_type if hasattr(inputs[0], 'element_info') else None
                    if first_control_type == "CheckBox":
                        print(f"[INFO] Clicking checkbox at position 0...")
                        try:
                            # Try to click using pywinauto first
                            inputs[0].click()
                        except:
                            # Fallback: get rectangle and click center
                            try:
                                rect = inputs[0].rectangle()
                                center_x = (rect.left + rect.right) // 2
                                center_y = (rect.top + rect.bottom) // 2
                                pyautogui.click(center_x, center_y)
                            except:
                                pass
                        time.sleep(0.3)
                        input_index = 1
                except:
                    pass
            
            # Fill login - use Tab to navigate and type
            if input_index < len(inputs):
                print(f"[INFO] Filling login in input {input_index}...")
                try:
                    # Try to focus the input using pywinauto
                    inputs[input_index].set_focus()
                    time.sleep(0.2)
                    # Clear existing text
                    pyautogui.hotkey('ctrl', 'a')
                    time.sleep(0.1)
                    # Type login
                    pyautogui.write(login, interval=0.05)
                    time.sleep(0.3)
                except:
                    # Fallback: use Tab navigation
                    pyautogui.press('tab', presses=input_index)
                    time.sleep(0.2)
                    pyautogui.hotkey('ctrl', 'a')
                    time.sleep(0.1)
                    pyautogui.write(login, interval=0.05)
                    time.sleep(0.3)
                input_index += 1
            
            # Fill password
            if input_index < len(inputs):
                print(f"[INFO] Filling password in input {input_index}...")
                try:
                    # Try to focus the input using pywinauto
                    inputs[input_index].set_focus()
                    time.sleep(0.2)
                    # Clear existing text
                    pyautogui.hotkey('ctrl', 'a')
                    time.sleep(0.1)
                    # Type password
                    pyautogui.write(password, interval=0.05)
                    time.sleep(0.3)
                except:
                    # Fallback: use Tab navigation
                    pyautogui.press('tab')
                    time.sleep(0.2)
                    pyautogui.hotkey('ctrl', 'a')
                    time.sleep(0.1)
                    pyautogui.write(password, interval=0.05)
                    time.sleep(0.3)
                return True
            
            print(f"[ERROR] Not enough input controls to fill login and password")
            return False
        except Exception as e:
            print(f"[ERROR] Error filling login form: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def validate_login_success(self, expected_login: str, expected_server: str, timeout: int = 30) -> bool:
        """
        Validate login success by checking window title for account ID and server
        
        Args:
            expected_login: Expected login/account ID
            expected_server: Expected server name
            timeout: Maximum time to wait for validation
            
        Returns:
            True if login successful, False otherwise
        """
        try:
            start_time = time.time()
            print(f"[INFO] Validating login success (looking for account {expected_login} and server {expected_server})...")
            sys.stdout.flush()
            
            while time.time() - start_time < timeout:
                # Try to find MetaTrader main window
                window_patterns = [
                    "MetaTrader",
                    "terminal",
                    "MT4",
                    "MT5"
                ]
                
                for pattern in window_patterns:
                    try:
                        windows = findwindows.find_windows(title_re=f".*{pattern}.*")
                        if windows:
                            for hwnd in windows:
                                try:
                                    window_text = findwindows.find_element(handle=hwnd).window_text()
                                    window_text_lower = window_text.lower()
                                    
                                    # Check if window title contains account ID and server
                                    if expected_login.lower() in window_text_lower and expected_server.lower() in window_text_lower:
                                        print(f"[OK] Login successful! Found account {expected_login} and server {expected_server} in window title: '{window_text}'")
                                        sys.stdout.flush()
                                        return True
                                except:
                                    continue
                    except:
                        continue
                
                time.sleep(1)
            
            print(f"[ERROR] Login validation failed: Could not find account {expected_login} and server {expected_server} in window title after {timeout}s")
            sys.stdout.flush()
            return False
        except Exception as e:
            print(f"[ERROR] Error validating login success: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    
    def login(self) -> bool:
        """
        Perform login - to be implemented by subclasses
        
        Returns:
            True if login successful, False otherwise
        """
        raise NotImplementedError("Subclasses must implement login() method")
    
    def run(self) -> bool:
        """
        Main entry point - wait for window and perform login
        
        Returns:
            True if login successful, False otherwise
        """
        print(f"Starting MetaTrader login automation...", flush=True)
        print(f"  Path: {self.mt_path}", flush=True)
        print(f"  Login: {self.login_number}", flush=True)
        print(f"  Server: {self.server}", flush=True)
        sys.stdout.flush()  # Ensure output is flushed immediately
        sys.stderr.flush()
        
        # Wait for MetaTrader window - try multiple patterns
        window_patterns = [
            "MetaTrader",
            "terminal",
            "MT4",
            "MT5",
            "MetaTrader 4",
            "MetaTrader 5"
        ]
        
        window_found = False
        for pattern in window_patterns:
            print(f"  Trying to find window with pattern: {pattern}")
            sys.stdout.flush()
            if self.wait_for_window(pattern, timeout=10):
                window_found = True
                break
        
        if not window_found:
            print("[ERROR] Failed to find MetaTrader window with any pattern")
            sys.stdout.flush()
            return False
        
        # Perform login
        print("  Window found, starting login process...")
        sys.stdout.flush()
        result = self.login()
        sys.stdout.flush()
        return result
