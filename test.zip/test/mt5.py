"""
MetaTrader 5 login automation script
Implements server discovery using UI automation (no OCR/screenshots)
"""

import sys
import time
import os
from pathlib import Path

if sys.platform == 'win32':
    os.environ['PYTHONIOENCODING'] = 'utf-8'

sys.path.insert(0, str(Path(__file__).parent))
from base import MetaTraderLoginBase

try:
    import pyautogui
except ImportError:
    print("ERROR: pyautogui not installed. Install with: pip install pyautogui")
    sys.exit(1)


class MT5Login(MetaTraderLoginBase):
    """MetaTrader 5 specific login automation with server discovery"""
    
    def __init__(self, mt_path: str, login: str, password: str, server: str, timeout: int = 60):
        """Initialize MT5 login automation"""
        super().__init__(mt_path, login, password, server, timeout)
        self.current_row = 0
        self.max_rows = 0
    
    def navigate_to_server_window(self) -> bool:
        """
        Navigate to the server selection window
        
        Returns:
            True if window found and activated, False otherwise
        """
        sys.stdout.flush()
        
        open_account_window = self.find_window_by_title(
            "Open an Account|Open Account|Abrir una cuenta", 
            timeout=30
        )
        
        if not open_account_window:
            print("[ERROR] 'Open an Account' window not found")
            sys.stdout.flush()
            return False
        
        sys.stdout.flush()
        self.activate_window(open_account_window)
        
        return True
    
    def inject_server_and_trigger_search(self, window: any) -> bool:
        """
        Inject server name in the first input text field found in "Open an Account" window
        
        Args:
            window: Window object from pywinauto (Open an Account window)
        
        Returns:
            True if successful, False otherwise
        """
        sys.stdout.flush()
        
        try:
            # Find the first Edit control (input text field) in the window
            edits = window.descendants(class_name="Edit")
            if not edits or len(edits) == 0:
                print("[ERROR] No Edit control found in 'Open an Account' window")
                sys.stdout.flush()
                return False
            
            # Use the first Edit control found
            input_field = edits[0]
            print(f"[INFO] Found input field, writing server: '{self.server}'")
            sys.stdout.flush()
            
            # Focus the input field
            sys.stdout.flush()
            input_field.set_focus()
            time.sleep(0.2)
            
            # Clear any existing text and write server name
            sys.stdout.flush()
            pyautogui.hotkey('ctrl', 'a')  # Select all
            time.sleep(0.1)
            pyautogui.write(self.server, interval=0.05)
            print(f"[OK] Server name written: '{self.server}'")
            sys.stdout.flush()
            
            # Press Enter to search - this should trigger the search
            time.sleep(0.2)
            self.press_key('enter')
            
            return True
            
        except Exception as e:
            print(f"[ERROR] Error injecting server name: {e}")
            import traceback
            traceback.print_exc()
            sys.stdout.flush()
            return False
    
    def wait_for_server_list_to_load(self, window: any, initial_count: int, timeout: int = 60) -> bool:
        """
        Wait for server list to load by detecting when there are more rows than initially.
        
        Args:
            window: Window object from pywinauto
            initial_count: Initial number of rows in the table
            timeout: Maximum time to wait (default 60 seconds for non-existent brokers)
            
        Returns:
            True if list loaded with more rows than initial, False if timeout
        """
        sys.stdout.flush()
        
        import time
        start_time = time.time()
        check_interval = 0.5  # Check every 0.5 seconds
        
        print(f"[INFO] Waiting for server list to load (initial count: {initial_count})...")
        sys.stdout.flush()
        
        while time.time() - start_time < timeout:
            try:
                # Check item count
                current_count = self.get_list_items_count(window)
                
                # If we have more rows than initially, list has loaded
                if current_count > initial_count:
                    print(f"[OK] Server list loaded: {current_count} items found (initial: {initial_count})")
                    sys.stdout.flush()
                    return True
                
                # Log progress every 4 seconds
                elapsed = int(time.time() - start_time)
                if elapsed > 0 and elapsed % 4 == 0:  # Log every 4 seconds
                    print(f"[INFO] Still waiting... current: {current_count}, initial: {initial_count} ({elapsed}s elapsed)")
                    sys.stdout.flush()
                
                time.sleep(check_interval)
                
            except Exception as e:
                sys.stdout.flush()
                time.sleep(check_interval)
        
        # Timeout reached - check final count
        final_count = self.get_list_items_count(window)
        
        if final_count > initial_count:
            print(f"[OK] Server list loaded: {final_count} items found (initial: {initial_count})")
            sys.stdout.flush()
            return True
        else:
            print(f"[ERROR] Timeout ({timeout}s) reached. Final count: {final_count}, initial: {initial_count}")
            print(f"[ERROR] No servers found for '{self.server}'. Cancelling login process.")
            sys.stdout.flush()
            return False
    
    def count_server_rows(self, window: any) -> int:
        """
        Count how many server rows are available in the list
        Note: The last row is not a valid option, so we subtract 1
        Note: This function is only called after wait_for_server_list_to_load returns True,
        which means we have more than 1 item (single item = loading row, not a server)
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            Number of valid server rows (total - 1)
        """
        sys.stdout.flush()
        
        # Get count of list items
        # NOTE: This should not move the focus, but some pywinauto methods might
        total_count = self.get_list_items_count(window)
        
        # If we somehow have only 1 item here, it means wait_for_server_list_to_load
        # should have failed, but we'll handle it gracefully
        if total_count <= 1:
            sys.stdout.flush()
            return 0
        
        # Normal case: Subtract 1 because the last row is not a valid option
        valid_count = max(0, total_count - 1)
        
        if total_count > 0:
            sys.stdout.flush()
        else:
            sys.stdout.flush()
        
        # IMPORTANT: After counting, ensure we're still at the top
        # Some pywinauto methods might have moved the selection
        sys.stdout.flush()
        try:
            self.activate_window(window)
            pyautogui.press('home')
            sys.stdout.flush()
        except Exception as e:
            sys.stdout.flush()
        
        return valid_count
    
    def navigate_to_row(self, row_number: int) -> bool:
        """
        Navigate to a specific row in the server list
        
        Args:
            row_number: Row number to navigate to (0-based)
            
        Returns:
            True if navigation successful, False otherwise
        """
        if row_number == 0:
            sys.stdout.flush()
            pyautogui.press('home')
            return True
        
        if row_number > self.current_row:
            steps = row_number - self.current_row
            sys.stdout.flush()
            for i in range(steps):
                pyautogui.press('down')
        elif row_number < self.current_row:
            steps = self.current_row - row_number
            sys.stdout.flush()
            for i in range(steps):
                pyautogui.press('up')
        
        self.current_row = row_number
        return True
    
    def try_login_with_current_row(self, window: any) -> bool:
        """
        Try to login using the currently selected row
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            True if login successful, False otherwise
        """
        sys.stdout.flush()
        
        if self.current_row == 0:
            sys.stdout.flush()
            self.activate_window(window)
            pyautogui.press('home')
            sys.stdout.flush()
        else:
            self.navigate_to_row(self.current_row)
        
        sys.stdout.flush()
        self.press_key('enter')
        
        sys.stdout.flush()
        login_window = self.find_window_by_title("Login|Account|Login to trade", timeout=10)
        
        if not login_window:
            print(f"  [ERROR] Login form window not found")
            sys.stdout.flush()
            return False
        
        sys.stdout.flush()
        self.activate_window(login_window)
        
        sys.stdout.flush()
        if not self.fill_login_form(login_window, self.login_number, self.password):
            print(f"  [ERROR] Failed to fill login form")
            sys.stdout.flush()
            return False
        
        sys.stdout.flush()
        self.press_key('enter')
        
        sys.stdout.flush()
        return True
    
    def detect_end_of_list(self, window: any) -> bool:
        """
        Detect if we've reached the end of the server list
        Note: max_rows is already the valid count (total - 1), so we check >= max_rows
        
        Args:
            window: Window object from pywinauto
            
        Returns:
            True if at end of list, False otherwise
        """
        if self.max_rows > 0 and self.current_row >= self.max_rows:
            return True
        
        return False
    
    def server_discovery(self) -> bool:
        """
        New login flow:
        1. Navigate to "Open an Account"
        2. Count initial rows in the table
        3. Find the first input text field and write server name
        4. Wait until there are more rows than initially
        5. Press Escape 3 times, then Alt+F, then 13x down arrow, then Enter
        6. Look for window with title "Login" and fill login form
        
        Returns:
            True if login successful, False otherwise
        """
        sys.stdout.flush()
        
        if not self.navigate_to_server_window():
            return False
        
        window = self.find_window_by_title("Open an Account|Open Account|Abrir una cuenta", timeout=5)
        if not window:
            print("[ERROR] Could not get window reference")
            sys.stdout.flush()
            return False
        
        # DEBUG: Log complete window information
        print("\n" + "=" * 80)
        print("[DEBUG] ========== OPEN AN ACCOUNT WINDOW DEBUG ==========")
        print("=" * 80)
        sys.stdout.flush()
        
        try:
            # Window basic info
            print(f"\n[DEBUG] Window Title: {window.window_text()}")
            print(f"[DEBUG] Window Class: {window.class_name()}")
            print(f"[DEBUG] Window Handle: {window.handle}")
            sys.stdout.flush()
            
            try:
                rect = window.rectangle()
                print(f"[DEBUG] Window Rectangle: left={rect.left}, top={rect.top}, right={rect.right}, bottom={rect.bottom}")
                print(f"[DEBUG] Window Size: width={rect.width()}, height={rect.height()}")
            except Exception as e:
                print(f"[DEBUG] Could not get window rectangle: {e}")
            sys.stdout.flush()
            
            # Get all descendants
            print(f"\n[DEBUG] --- All Descendants ---")
            try:
                all_descendants = window.descendants()
                print(f"[DEBUG] Total descendants: {len(all_descendants)}")
                sys.stdout.flush()
                
                # Group by control type
                control_types = {}
                for i, control in enumerate(all_descendants):
                    try:
                        ctrl_type = control.element_info.control_type if hasattr(control, 'element_info') else "Unknown"
                        if ctrl_type not in control_types:
                            control_types[ctrl_type] = []
                        control_types[ctrl_type].append(control)
                    except:
                        pass
                
                print(f"\n[DEBUG] Control types found: {len(control_types)}")
                for ctrl_type, controls in sorted(control_types.items()):
                    print(f"[DEBUG]   - {ctrl_type}: {len(controls)} controls")
                sys.stdout.flush()
                
                # Detailed info for Edit controls (input fields)
                print(f"\n[DEBUG] --- Edit Controls (Input Fields) ---")
                try:
                    edits = window.descendants(class_name="Edit")
                    print(f"[DEBUG] Found {len(edits)} Edit controls")
                    for i, edit in enumerate(edits):
                        try:
                            edit_text = edit.window_text()
                            edit_class = edit.class_name()
                            try:
                                rect = edit.rectangle()
                                print(f"[DEBUG]   Edit [{i}]:")
                                print(f"[DEBUG]     Text: '{edit_text}'")
                                print(f"[DEBUG]     Class: {edit_class}")
                                print(f"[DEBUG]     Rectangle: ({rect.left},{rect.top})-({rect.right},{rect.bottom})")
                            except:
                                print(f"[DEBUG]   Edit [{i}]: Text='{edit_text}', Class={edit_class}")
                        except Exception as e:
                            print(f"[DEBUG]   Edit [{i}]: Error - {e}")
                except Exception as e:
                    print(f"[DEBUG] Error getting Edit controls: {e}")
                sys.stdout.flush()
                
                # Detailed info for ListView controls
                print(f"\n[DEBUG] --- ListView Controls ---")
                try:
                    listviews = window.descendants(class_name="SysListView32")
                    print(f"[DEBUG] Found {len(listviews)} SysListView32 controls")
                    for i, lv in enumerate(listviews):
                        try:
                            print(f"[DEBUG]   ListView [{i}]:")
                            print(f"[DEBUG]     Text: {lv.window_text()}")
                            print(f"[DEBUG]     Class: {lv.class_name()}")
                            try:
                                rect = lv.rectangle()
                                print(f"[DEBUG]     Rectangle: ({rect.left},{rect.top})-({rect.right},{rect.bottom})")
                            except:
                                pass
                            
                            # Get item count
                            try:
                                count = lv.item_count()
                                print(f"[DEBUG]     Item Count: {count}")
                                
                                # Try to get first few items
                                if count > 0:
                                    print(f"[DEBUG]     First 5 items:")
                                    for row_idx in range(min(5, count)):
                                        try:
                                            row_texts = lv.item_texts(row_idx)
                                            if isinstance(row_texts, (list, tuple)):
                                                display_text = " | ".join(str(t).strip() for t in row_texts if str(t).strip())
                                            else:
                                                display_text = str(row_texts).strip()
                                            print(f"[DEBUG]       Row [{row_idx}]: {display_text}")
                                        except Exception as e:
                                            print(f"[DEBUG]       Row [{row_idx}]: Error - {e}")
                                    if count > 5:
                                        print(f"[DEBUG]       ... and {count - 5} more rows")
                            except Exception as e:
                                print(f"[DEBUG]     Item Count: Error - {e}")
                        except Exception as e:
                            print(f"[DEBUG]     Error processing ListView: {e}")
                except Exception as e:
                    print(f"[DEBUG] Error getting ListView controls: {e}")
                sys.stdout.flush()
                
                # Detailed info for all other important controls
                print(f"\n[DEBUG] --- Other Important Controls ---")
                for ctrl_type in ["Button", "ComboBox", "Static", "List"]:
                    try:
                        controls = window.descendants(control_type=ctrl_type)
                        if controls:
                            print(f"[DEBUG] Found {len(controls)} {ctrl_type} controls")
                            for i, ctrl in enumerate(controls[:5]):  # First 5 only
                                try:
                                    ctrl_text = ctrl.window_text()
                                    ctrl_class = ctrl.class_name()
                                    print(f"[DEBUG]   {ctrl_type} [{i}]: Text='{ctrl_text}', Class={ctrl_class}")
                                except:
                                    print(f"[DEBUG]   {ctrl_type} [{i}]: (error getting info)")
                            if len(controls) > 5:
                                print(f"[DEBUG]   ... and {len(controls) - 5} more {ctrl_type} controls")
                    except:
                        pass
                sys.stdout.flush()
                
            except Exception as e:
                print(f"[DEBUG] Error getting descendants: {e}")
                import traceback
                traceback.print_exc()
                sys.stdout.flush()
            
        except Exception as e:
            print(f"[DEBUG] Error in window debug: {e}")
            import traceback
            traceback.print_exc()
            sys.stdout.flush()
        
        print("\n" + "=" * 80)
        print("[DEBUG] ========== END OPEN AN ACCOUNT WINDOW DEBUG ==========")
        print("=" * 80 + "\n")
        sys.stdout.flush()
        
        # Step 1: Count initial rows in the table
        print("[INFO] Counting initial rows in the table...")
        sys.stdout.flush()
        initial_row_count = self.get_list_items_count(window)
        print(f"[INFO] Initial row count: {initial_row_count}")
        sys.stdout.flush()
        
        # Step 2: Find the first input text field and write server name
        if not self.inject_server_and_trigger_search(window):
            return False
        
        # Step 3: Wait until there are more rows than initially
        if not self.wait_for_server_list_to_load(window, initial_row_count, timeout=60):
            print("[ERROR] Server list did not load. No servers found or broker does not exist. Cancelling.")
            sys.stdout.flush()
            return False
        
        # Step 4: Press Escape 3 times to close dialogs
        print("[INFO] Pressing Escape 3 times...")
        sys.stdout.flush()
        pyautogui.press('escape')
        time.sleep(0.3)
        pyautogui.press('escape')
        time.sleep(0.3)
        pyautogui.press('escape')
        time.sleep(0.5)
        
        # Step 5: Open File menu (Alt+F) and navigate
        print("[INFO] Opening File menu (Alt+F)...")
        sys.stdout.flush()
        pyautogui.hotkey('alt', 'f')
        time.sleep(0.5)
        
        print("[INFO] Navigating down 13 times...")
        sys.stdout.flush()
        for i in range(13):
            pyautogui.press('down')
            time.sleep(0.1)
        
        print("[INFO] Pressing Enter...")
        sys.stdout.flush()
        pyautogui.press('enter')
        time.sleep(0.5)
        
        sys.stdout.flush()
        login_window = self.find_window_by_title("Login", timeout=10)
        
        if not login_window:
            sys.stdout.flush()
            return False
        
        sys.stdout.flush()
        
        sys.stdout.flush()
        
        try:
            window_text = login_window.window_text()
            sys.stdout.flush()
            
            try:
                descendants = login_window.descendants()
                sys.stdout.flush()
                
                for i, control in enumerate(descendants[:50]):  # Limit to first 50
                    try:
                        control_text = control.window_text()
                        control_class = control.class_name()
                        if control_text or control_class:
                            sys.stdout.flush()
                    except:
                        pass
                
                sys.stdout.flush()
                comboboxes = login_window.descendants(class_name="ComboBox")
                sys.stdout.flush()
                
                server_combo = None
                server_items = []
                
                for i, combo in enumerate(comboboxes):
                    try:
                        combo_text = combo.window_text()
                        sys.stdout.flush()
                        
                        items = None
                        try:
                            items = combo.item_texts()
                            if items:
                                for idx, item in enumerate(items):
                                    pass  # Just iterate through items
                        except Exception as e1:
                            try:
                                # Method 2: Try items()
                                items_objs = combo.items()
                                if items_objs:
                                    items = []
                                    for idx, item in enumerate(items_objs):
                                        try:
                                            item_text = item.window_text()
                                            items.append(item_text)
                                        except:
                                            pass
                            except Exception as e2:
                                try:
                                    combo.expand()
                                    items = combo.item_texts()
                                    if items:
                                        for idx, item in enumerate(items):
                                            pass  # Just iterate through items
                                    combo.collapse()
                                except Exception as e3:
                                    pass
                        
                        if items and len(items) > 1:
                            server_combo = combo
                            server_items = items
                            sys.stdout.flush()
                        
                    except Exception as e:
                        sys.stdout.flush()
                
                if server_combo:
                    print(f"\n[Step 7] Writing server name directly in ComboBox: '{self.server}'")
                    sys.stdout.flush()
                    
                    try:
                        # Focus the combobox and write the server name directly
                        server_combo.set_focus()
                        time.sleep(0.2)
                        pyautogui.hotkey('ctrl', 'a')  # Select all existing text
                        time.sleep(0.1)
                        pyautogui.write(self.server, interval=0.05)
                        print(f"[OK] Server name written in ComboBox: '{self.server}'")
                        sys.stdout.flush()
                    except Exception as e:
                        print(f"[ERROR] Could not write server name in ComboBox: {e}")
                        sys.stdout.flush()
                        return False
                else:
                    print(f"[ERROR] Could not find server ComboBox")
                    sys.stdout.flush()
                    return False
                
                print(f"\n[Step 8] Filling login and password fields...")
                sys.stdout.flush()
                
                login_field = None
                try:
                    edits = login_window.descendants(class_name="Edit")
                    if edits and len(edits) > 0:
                        login_field = edits[0]  # First Edit is usually login
                        sys.stdout.flush()
                except:
                    pass
                
                if not login_field:
                    # Try ComboBox for login
                    try:
                        login_combos = [c for c in comboboxes if c != server_combo]
                        if login_combos:
                            login_field = login_combos[0]
                            print(f"[INFO] Found login ComboBox field")
                            sys.stdout.flush()
                    except:
                        pass
                
                if login_field:
                    try:
                        login_field.set_focus()
                        pyautogui.hotkey('ctrl', 'a')
                        pyautogui.write(self.login_number, interval=0.05)
                        print(f"[OK] Login field filled: {self.login_number}")
                        sys.stdout.flush()
                    except Exception as e:
                        print(f"[ERROR] Could not fill login field: {e}")
                        sys.stdout.flush()
                        return False
                else:
                    print(f"[ERROR] Could not find login field")
                    sys.stdout.flush()
                    return False
                
                # Find password field (Edit)
                password_field = None
                try:
                    edits = login_window.descendants(class_name="Edit")
                    if edits and len(edits) > 1:
                        password_field = edits[1]  # Second Edit is usually password
                        print(f"[INFO] Found password Edit field")
                        sys.stdout.flush()
                except:
                    pass
                
                if password_field:
                    try:
                        password_field.set_focus()
                        pyautogui.hotkey('ctrl', 'a')
                        pyautogui.write(self.password, interval=0.05)
                        print(f"[OK] Password field filled")
                        sys.stdout.flush()
                    except Exception as e:
                        print(f"[ERROR] Could not fill password field: {e}")
                        sys.stdout.flush()
                        return False
                else:
                    print(f"[ERROR] Could not find password field")
                    sys.stdout.flush()
                    return False
                
                # Step 9: Press Enter to submit login
                print(f"\n[Step 9] Pressing Enter to submit login...")
                sys.stdout.flush()
                self.press_key('enter')
                print(f"[OK] Enter pressed, login submitted")
                sys.stdout.flush()
                
                # Step 10: Press Ctrl+E after login
                print(f"\n[Step 10] Pressing Ctrl+E after login...")
                sys.stdout.flush()
                time.sleep(0.5)  # Small delay to ensure login is processed
                pyautogui.hotkey('ctrl', 'e')
                print(f"[OK] Ctrl+E pressed")
                sys.stdout.flush()
                
            except Exception as e:
                print(f"[WINDOW CONTENT] Error getting descendants: {e}")
                sys.stdout.flush()
            
        except Exception as e:
            print(f"[ERROR] Error logging window content: {e}")
            import traceback
            traceback.print_exc()
            sys.stdout.flush()
        
        print("=" * 80)
        print("[INFO] Window content logged. Waiting for next instructions...")
        sys.stdout.flush()
        
        # For now, return True to indicate we found the window
        # The actual login validation will be done in the next step
        return True
    
    def login(self) -> bool:
        """
        Perform MT5 login using server discovery
        
        Returns:
            True if login successful, False otherwise
        """
        print("\n=== Starting MT5 Login Process ===")
        sys.stdout.flush()
        
        try:
            return self.server_discovery()
        except Exception as e:
            print(f"\n[ERROR] Error during MT5 login: {e}")
            import traceback
            traceback.print_exc()
            sys.stdout.flush()
            sys.stderr.flush()
            return False


def main():
    """Main entry point for MT5 login script"""
    try:
        # Force unbuffered output
        sys.stdout.reconfigure(line_buffering=True) if hasattr(sys.stdout, 'reconfigure') else None
        sys.stderr.reconfigure(line_buffering=True) if hasattr(sys.stderr, 'reconfigure') else None
        
        print("=" * 60, flush=True)
        print("MT5 Login Script Starting", flush=True)
        print("=" * 60, flush=True)
        sys.stdout.flush()
        sys.stderr.flush()
        
        if len(sys.argv) < 5:
            print("[ERROR] Usage: python mt5.py <mt_path> <login> <password> <server>", flush=True)
            print(f"[ERROR] Received {len(sys.argv)} arguments: {sys.argv}", flush=True)
            sys.stdout.flush()
            sys.exit(1)
        
        mt_path = sys.argv[1]
        login = sys.argv[2]
        password = sys.argv[3]
        server = sys.argv[4]
        
        print(f"Arguments received:", flush=True)
        print(f"  mt_path: {mt_path}", flush=True)
        print(f"  login: {login}", flush=True)
        print(f"  password: {'*' * len(password)}", flush=True)
        print(f"  server: {server}", flush=True)
        sys.stdout.flush()
        
        print("[INFO] Creating MT5Login object...", flush=True)
        sys.stdout.flush()
        login_automation = MT5Login(mt_path, login, password, server)
        print("[OK] Login automation object created, calling run()...", flush=True)
        sys.stdout.flush()
        
        print("[INFO] Starting login process...", flush=True)
        sys.stdout.flush()
        success = login_automation.run()
        
        print("=" * 60, flush=True)
        if success:
            print("[OK] Login script completed successfully", flush=True)
        else:
            print("[ERROR] Login script failed", flush=True)
        print("=" * 60, flush=True)
        sys.stdout.flush()
        sys.stderr.flush()
        
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n[ERROR] Script interrupted by user", flush=True)
        sys.stdout.flush()
        sys.stderr.flush()
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Fatal error in main(): {e}", flush=True)
        import traceback
        traceback.print_exc(file=sys.stdout)
        sys.stdout.flush()
        sys.stderr.flush()
        sys.exit(1)


if __name__ == "__main__":
    main()
